import ContentLayout from '@/app/components/ContentLayout';

export default function Vales() {
  return (
    <ContentLayout title="Vales de Tesorería">
      <div className="space-y-4 text-gray-300">
        <p>Contenido de la página de Vales</p>
        {/* Aquí irá el contenido específico de la página */}
      </div>
    </ContentLayout>
  );
} 